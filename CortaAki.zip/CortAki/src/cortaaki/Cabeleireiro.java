package cortaaki;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Cabeleireiro {
	String nome;
	int id;
	}
