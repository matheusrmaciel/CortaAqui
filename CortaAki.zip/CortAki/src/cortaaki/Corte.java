package cortaaki;
import javax.swing.JOptionPane;

public class Corte extends Servicos{
	String tipodecorte;
	double valor;
	char sexo;
	public Corte(int id){
		super(id);
	}
	
	public void mostrardesc(String descricao){
		JOptionPane.showMessageDialog(null, "A descri��o do servi�o �: " + descricao + ".", "Ok", JOptionPane.WARNING_MESSAGE);
	}
	public void cortarcabelo(){
		JOptionPane.showMessageDialog(null, "Cabelo Cortado!", "Ok", JOptionPane.WARNING_MESSAGE);
		}
	public void cortarcabelo(String tipodecorte){
		JOptionPane.showMessageDialog(null, "Cabelo Cortado assim:"+ tipodecorte + "!", "Ok", JOptionPane.INFORMATION_MESSAGE);		
	}
}
