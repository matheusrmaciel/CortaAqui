package cortaaki;
import javax.swing.JOptionPane;


public class Main {

	public static void main(String[] args) {
		Servicos x = new Servicos(1);
		x.descricao = JOptionPane.showInputDialog(null, "Qual a descri��o do seu servi�o?", "Ok", JOptionPane.WARNING_MESSAGE);
		x.mostrardesc(x.descricao);
		

	}

}
