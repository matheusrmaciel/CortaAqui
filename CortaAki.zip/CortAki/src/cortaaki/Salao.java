package cortaaki;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Salao {
	String nome;
	String endere�o;
	String telefone;
	
	ArrayList<Cabeleireiro>  cabeleireiros = new ArrayList();
	public void adicionarcabeleireiro(Cabeleireiro cabeleireiro){
		cabeleireiros.add(cabeleireiro);
	}
	

}
