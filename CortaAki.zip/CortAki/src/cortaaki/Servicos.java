package cortaaki;
import javax.swing.JOptionPane;

public class Servicos {
	int id;
	String descricao;
	public Servicos(int id){
		this.id = id;
	}
	public void mostrardesc(String descricao){
		JOptionPane.showMessageDialog(null, "A descri��o do servi�o �: " + descricao + ".", "Ok", JOptionPane.WARNING_MESSAGE);
	}
}
